﻿using System.Web.Mvc;
using ContactInformation.Controllers;
using ContactInformation.Models;
using ContactInformation.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace ContactInformation.Tests.Controllers
{
    [TestClass]
    public class ContactControllerTest
    {
        private Mock<IContactInfoService> contactInfoService;


        [TestInitialize]
        public void Initialize()
        {
            contactInfoService = new Mock<IContactInfoService>();
        }

        [TestMethod]
        public void CreateValidContact()
        {
            // Arrange
            var contact = new Contact();
            contactInfoService.Expect(s => s.CreateContact(contact)).Returns(true);
            var controller = new ContactController(contactInfoService.Object);
        
            // Act
            var result = (RedirectToRouteResult)controller.Create(contact);

            // Assert
            Assert.AreEqual("ContactList", result.RouteValues["action"]);
        }


        [TestMethod]
        public void CreateInvalidContact()
        {
            // Arrange
            var contact = new Contact();
            
            contactInfoService.Expect(s => s.CreateContact(contact)).Returns(false);
            var controller = new ContactController(contactInfoService.Object);

            // Act
            var result = (ViewResult)controller.Create(contact);

            // Assert
            Assert.AreEqual("Contact", result.ViewName);
        }


    }
}
