﻿using System.Web.ModelBinding;

namespace ContactInfoService
{
    public class ModelStateValidation : IValidation
    {
        private ModelStateDictionary modelState;

        public ModelStateValidation(ModelStateDictionary modelState)
        {
            this.modelState = modelState;
        }
        public ModelStateValidation()
        {
            //this.modelState = modelState;
        }

        public void AddError(string key, string errorMessage)
        {
            modelState.AddModelError(key, errorMessage);
        }

        public bool IsValid
        {
            get { return modelState.IsValid; }
        }
    }
}