﻿
namespace ContactInfoService
{
    public interface IValidation
    {
        void AddError(string key, string errorMessage);
        bool IsValid { get; }
    }
}
