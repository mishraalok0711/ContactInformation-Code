﻿
namespace ContactInformation.Interfaces
{
    public interface IValidation
    {
        void AddError(string key, string errorMessage);
        bool IsValid { get; }
    }
}
