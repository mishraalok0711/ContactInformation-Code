﻿using System;
using System.Collections.Generic;
using ContactInformation.Models;

namespace ContactInformation.Interfaces
{
    public interface IContactInfoRepository
    {
        Contact CreateContact(Contact contactToCreate);
        void DeleteContact(Contact contactToDelete);
        Contact EditContact(Contact contactToEdit);
        Contact GetContact(int id);
        IEnumerable<Contact> ListContacts();
    }
}