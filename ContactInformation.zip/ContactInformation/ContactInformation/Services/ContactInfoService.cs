﻿using System;
using System.Collections.Generic;
using ContactInformation.Models;
using ContactInformation.Interfaces;
using System.Text.RegularExpressions;

namespace ContactInformation.Services
{
    public class ContactInfoService : IContactInfoService
    {
        private IValidation validation;
        private IContactInfoRepository contactInfoRepository;


        public ContactInfoService(IValidation validation)
            : this(validation, new ContactInfoRepository())
        {
            
        }


        public ContactInfoService(IValidation objValidation, IContactInfoRepository objContactInfoRepository)
        {
            validation = objValidation;
            contactInfoRepository = objContactInfoRepository;
        }


        public bool ValidateContact(Contact validateContact)
        {
            if (validateContact.FirstName.Trim().Length == 0)
                validation.AddError("FirstName", "First name is required.");
            if (validateContact.LastName.Trim().Length == 0)
                validation.AddError("LastName", "Last name is required.");
            if (validateContact.PhoneNumber.Length < 10 )
                validation.AddError("PhoneNumber", "Invalid phone number. Minimum 10 digits");
            if (validateContact.Email.Length > 0 && !Regex.IsMatch(validateContact.Email, @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$"))
                validation.AddError("Email", "Invalid email address.");
            return validation.IsValid;
        }


        #region IContactInfoService 

        public bool CreateContact(Contact createContact)
        {
            if (!ValidateContact(createContact))
                return false;
            try
            {
                contactInfoRepository.CreateContact(createContact);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        public bool EditContact(Contact editContact)
        {
           if (!ValidateContact(editContact))
                return false;
            try
            {
                contactInfoRepository.EditContact(editContact);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        public bool DeleteContact(Contact deleteContact)
        {
            try
            {
                contactInfoRepository.DeleteContact(deleteContact);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        public Contact GetContact(int id)
        {
            return contactInfoRepository.GetContact(id);
        }

        public IEnumerable<Contact> ListContacts()
        {
            return contactInfoRepository.ListContacts();
        }

        #endregion
    }
}