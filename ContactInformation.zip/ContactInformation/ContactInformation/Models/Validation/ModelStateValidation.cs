﻿using ContactInformation.Interfaces;
using System.Web.Mvc;

namespace ContactInformation.Models.Validation
{
    public class ModelStateValidation : IValidation
    {
        private ModelStateDictionary modelState;

        public ModelStateValidation(ModelStateDictionary modelState)
        {
            this.modelState = modelState;
        }

        public void AddError(string key, string errorMessage)
        {
            modelState.AddModelError(key, errorMessage);
        }

        public bool IsValid
        {
            get { return modelState.IsValid; }
        }
    }
}