﻿using System.Collections.Generic;
using System.Linq;
using ContactInformation.Interfaces;

namespace ContactInformation.Models
{
    public class ContactInfoRepository : IContactInfoRepository
    {
        private ContactInformationEntities contactInformationEntities = new ContactInformationEntities();
        public Contact GetContact(int id)
        {
            return (from c in contactInformationEntities.Contacts
                where c.Id == id
                select c).FirstOrDefault();
        }


        public IEnumerable<Contact> ListContacts()
        {
            return contactInformationEntities.Contacts.ToList();
        }


        public Contact CreateContact(Contact contactToCreate)
        {
            contactInformationEntities.AddToContacts(contactToCreate);
            contactInformationEntities.SaveChanges();
            return contactToCreate;
        }


        public Contact EditContact(Contact contactToEdit)
        {
            var contact = GetContact(contactToEdit.Id);
            contactInformationEntities.ApplyCurrentValues(contact.EntityKey.EntitySetName, contactToEdit);
            contactInformationEntities.SaveChanges();
            return contactToEdit;
        }


        public void DeleteContact(Contact contactToDelete)
        {
            var contact = GetContact(contactToDelete.Id);
            contactInformationEntities.DeleteObject(contact);
            contactInformationEntities.SaveChanges();
        }
    }
}