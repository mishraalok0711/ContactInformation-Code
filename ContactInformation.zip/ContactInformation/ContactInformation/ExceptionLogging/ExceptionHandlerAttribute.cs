﻿using System;
using System.Web.Mvc;
using ContactInformation.Models;

namespace ContactInformation.ExceptionLogging
{
    public class ExceptionHandlerAttribute : FilterAttribute, IExceptionFilter
    {
        public void OnException(ExceptionContext filterContext)
        {
            ContactInformationEntities contactInformationEntities = new ContactInformationEntities();
            if (!filterContext.ExceptionHandled)
            {
                ExceptionLogger logger = new ExceptionLogger()
                {
                    ExceptionMessage = filterContext.Exception.Message,
                    StackTrace = filterContext.Exception.StackTrace,
                    ControllerName = filterContext.RouteData.Values["controller"].ToString(),
                    ExceptionDateTime = DateTime.Now
                };
            
                contactInformationEntities.ExceptionLoggers.AddObject(logger);
                contactInformationEntities.SaveChanges();
                filterContext.ExceptionHandled = true;
            }
        }
    }
}